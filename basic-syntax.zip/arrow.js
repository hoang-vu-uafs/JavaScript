const func1 = function () {
  return "dfd";
};

function func2() {
  return "";
}

const func3 = (hi, hi2) => {
  console.log("fdfd");
};
